//
//  ViewController.swift
//  App_8
//
//  Created by Khs on 08/01/23.
//

import UIKit

class ViewController: UIViewController {

    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view.
    }

    @IBAction func setnotification(_ sender: Any) {
            let setNotification=UILocalNotification()
            setNotification.alertTitle="Localnotification Example🥳"
            setNotification.alertBody="This is Localnotification example using SWIFT!📡🎊"
        setNotification.fireDate=(sender as AnyObject).date
            setNotification.applicationIconBadgeNumber=UIApplication.shared.applicationIconBadgeNumber+1
            UIApplication.shared.scheduleLocalNotification(setNotification)
    }
    
}

