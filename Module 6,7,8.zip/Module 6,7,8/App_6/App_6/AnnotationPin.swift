//
//  AnnotationPin.swift
//  App_6
//
//  Created by Khs on 07/01/23.
//

import MapKit

class AnnotationPin: NSObject, MKPointAnnotation {
    
    var title: String?
    var Subtitle: String?
    var Coordinate: CLLocationCoordinate2D
    
    init(title: String, Subtitle: String, Coordinate: CLLocationCoordinate2D){
        self.title = title
        self.Subtitle = Subtitle
        self.Coordinate = Coordinate

    }
    
    
}
