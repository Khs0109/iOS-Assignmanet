//
//  ViewController.swift
//  App_6
//
//  Created by Khs on 07/01/23.
//

import UIKit
import MapKit

class ViewController: UIViewController, MKMapViewDelegate{

    @IBOutlet weak var myMap: MKMapView!
    
    var pin:AnnotationPin!
    
   /* Burj Khalifa/Coordinates
    25.1972° N, 25.1972° E*/
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        myMap.delegate = self
        
        // Do any additional setup after loading the view.
        
        /*let annotation = .MKPointAnnotation()
        annotation.coordinate = CLLocationCoordinate2D(latitude: 25.1972, longitude: 25.1972)
        annotation.title = "Burj Khalifa"
        annotation.subtitle = ""
        myMap.addAnnotation(annotation)*/
        
      /*  let region = MKCoordinateRegion(center: annotation, latitudinalMeters: 500, longitudinalMeters: 500)
        myMap.setRegion(region, animated: true)*/
        
        let coordinate = CLLocationCoordinate2D(latitude: 25.1972, longitude: 5.1972)
        let region = MKCoordinateRegion(center: coordinate, latitudinalMeters: 500,longitudinalMeters: 500)
        
        myMap.setRegion(region, animated: true)
        
        pin = AnnotationPin(title: "Burj Khalifa", Subtitle: "", Coordinate: coordinate); myMap.addAnnotation(pin as! MKAnnotation)
        
    }


}

