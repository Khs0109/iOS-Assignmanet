//
//  ViewController.swift
//  App_7
//
//  Created by Khs on 08/01/23.
//

import UIKit
import MapKit
import CoreLocation

class ViewController: UIViewController, CLLocationManagerDelegate, MKMapViewDelegate{

    @IBOutlet weak var location_txt: UITextField!
    @IBOutlet weak var mapview: MKMapView!
    
    var LocationManager = CLLocationManager()
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        LocationManager.delegate = self
        LocationManager.desiredAccuracy = kCLLocationAccuracyBest
        LocationManager.requestAlwaysAuthorization()
        LocationManager.requestWhenInUseAuthorization()
        
        mapview.delegate = self
        
        
        // Do any additional setup after loading the view.
    }

    @IBAction func btn_show(_ sender: Any) {
    }
    
    func getAddress()
    {
        let getCoder = CLGeocoder()
        getCoder.geocodeAddressString(location_txt.text!) {
            (placemarks, error)
            in
            guard let placemarks = placemarks, let location =
                    placemarks.first?.location
                    
                    else
                        
            {
                print ("No Location Found...")
                
                return

            }
            print (location)
            self.mapThis(destinationCord: location.coordinate)
        }
        
    }
    
    func locationManager(_ manager: CLLocationManager, didUpdateLocations locations: [CLLocation]) {
        print (locations)
    }
    
    func mapThis(destinationCord : CLLocationCoordinate2D)
    
    {
        
        let souceCordinate = (LocationManager.location?.coordinate)
        
        let soucePlacemark = MKPlacemark(coordinate: souceCordinate!)
        let destPlacemark = MKPlacemark(coordinate: destinationCord)
        
        let sourceItem = MKMapItem(placemark: soucePlacemark)
        let destItem = MKMapItem(placemark: destPlacemark)
        
        let destinationRequest = MKDirections.Request()
        destinationRequest.source = sourceItem
        destinationRequest.destination = destItem
        destinationRequest.transportType = .automobile
        destinationRequest.requestsAlternateRoutes = true
        
        let direction = MKDirections(request: destinationRequest)
        direction.calculate { (response, error) in
            guard let response = response else {
                if let error = error {
                    print("Something Went Wrong...: (")
                    
                }
                return
            }
            
            let routs = response.routes[0]
            self.mapview.addOverlay(routs.polyline)
            self.mapview.setVisibleMapRect(routs.polyline.boundingMapRect, animated: true)
            
        }
        
        
        
        
    }
}

