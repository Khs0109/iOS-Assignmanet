//
//  ViewController.swift
//  App_5
//
//  Created by Khs on 07/01/23.
//

import UIKit
import MapKit
import CoreLocation


class ViewController: UIViewController {

    @IBOutlet weak var mymap: MKMapView!
    
    var location=CLLocationManager()
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        location.requestAlwaysAuthorization()
        
        // Do any additional setup after loading the view.
        
    }

    @IBAction func mmap_mode(_ sender: UISegmentedControl) {
        
        if sender.selectedSegmentIndex==0
        {
            mymap.mapType = .standard
        }
        else
        {
            mymap.mapType = .hybrid
        }
        
        
    }
    
}

