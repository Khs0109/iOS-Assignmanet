//
//  ViewController.swift
//  App-15
//
//  Created by Khs on 13/12/22.
//

import UIKit

class ViewController: UIViewController {

    @IBOutlet weak var mytxt: UITextField!
    
    @IBOutlet weak var myimg: UIImageView!
    
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view.
    }
    
    override func touchesBegan(_ touches: Set<UITouch>, with event: UIEvent?) {
        view.endEditing(true)
    }

    @IBAction func btn_share(_ sender: Any) {
        //let share=UIActivityViewController(activityItems: [UIActivity.ActivityType.copyToPasteboard,UIActivity.ActivityType.mail], applicationActivities: nil)
        let share=UIActivityViewController(activityItems: [myimg.image!,mytxt.text!], applicationActivities: nil)
        present(share, animated: true, completion: nil)
        
    }
    
}

