//
//  SecondViewController.swift
//  App 1-2
//
//  Created by Khs on 13/12/22.
//

import UIKit

class SecondViewController: UIViewController {

    @IBOutlet weak var txt_unm: UITextField!
    
    @IBOutlet weak var txt_ps: UITextField!
    
    
    override func viewDidLoad() {
        super.viewDidLoad()

        // Do any additional setup after loading the view.
    }

   
    @IBAction func btn_lgin(_ sender: Any)
    {
        let alerterror = UIAlertController(title: "Log in", message: "You are Successfully Log in", preferredStyle: .alert)
        let btn = UIAlertAction(title: "okay", style: .default)
        alerterror.addAction(btn)
        self.present(alerterror,animated: true, completion: nil)
    }
    
}
