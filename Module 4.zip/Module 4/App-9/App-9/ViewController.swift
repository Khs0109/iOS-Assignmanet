//
//  ViewController.swift
//  App-9
//
//  Created by Khs on 13/12/22.
//

import UIKit
import AVKit
import AVFoundation

class ViewController: UIViewController {
    
    var myplayer=AVPlayerViewController()
    var playerobj=AVPlayer()

    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view.
    }

    @IBAction func btn_audio(_ sender: Any) {
        
        let path=URL(fileURLWithPath: Bundle.main.path(forResource: "mysong", ofType: "mp3")!)
        playerobj=AVPlayer(url: path)
        myplayer.player=playerobj
        playerobj.play()
        playerobj.volume=60
        present(myplayer, animated: true, completion: nil)
        
    }
    
    @IBAction func btn_video(_ sender: Any) {
        
        let path=URL(fileURLWithPath: Bundle.main.path(forResource: "videoplayback", ofType: "mp4")!)
        //let path=URL(string: "https://www.youtube.com/watch?v=g6fnFALEseI")
        playerobj=AVPlayer(url: path)
        myplayer.player=playerobj
        playerobj.play()
        playerobj.volume=60
        present(myplayer, animated: true, completion: nil)
        
    }
}

