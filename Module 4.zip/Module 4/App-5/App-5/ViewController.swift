//
//  ViewController.swift
//  App-5
//
//  Created by Khs on 13/12/22.
//

import UIKit

class ViewController: UIViewController {

    @IBOutlet weak var mylbl: UILabel!
    
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view.
    }

    @IBAction func btn_alert(_ sender: Any) {
        
        let alert = UIAlertController(title: "Alert", message: "Hello Alert..!!", preferredStyle: .alert)
        
        alert.addTextField { (txtname) in
            
            txtname.placeholder = "Enter Name"
        }
        
        alert.addAction(UIAlertAction(title: "Okay", style: .default, handler: {
            (alertaction) in
            let getTextfield = alert.textFields![0]
            self.mylbl.text = getTextfield.text!
        }))
        
        alert.addAction(UIAlertAction(title: "Cancle", style: .default, handler: nil))
        self.present(alert, animated: true, completion: nil)
    }
    
    
}

