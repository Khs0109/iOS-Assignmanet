//
//  StockViewController.swift
//  Financial Calculator
//
//  Created by Khs on 09/01/23.
//

import UIKit

class StockViewController: UIViewController {
    
    @IBOutlet weak var lbl_value: UILabel!
    
    @IBOutlet weak var txt_ammount: UITextField!
    
    @IBOutlet weak var txt_shareprice: UITextField!


    override func viewDidLoad() {
        super.viewDidLoad()

        // Do any additional setup after loading the view.
    }

    @IBAction func btn_calculate(_ sender: Any) {
        let sharePrice = Double(txt_shareprice.text!)!
                let amount = Double(txt_ammount.text!)!
                let numShares = amount / sharePrice
                let intShares = Int(numShares)
                let result = intShares - 1
                lbl_value.text = "\(result)"
    }
}
