//
//  LoanViewController.swift
//  Financial Calculator
//
//  Created by Khs on 09/01/23.
//

import UIKit

class LoanViewController: UIViewController {
    
    var principal = 10000.0  // loan amount
    var rate: Double = 0.0// annual interest rate
    var term = 5.0  // loan term in years
    
    @IBOutlet weak var myprogress: UIProgressView!
    
    @IBOutlet weak var lbl_value: UILabel!
    
    @IBOutlet weak var txt_ammount: UITextField!
    
    @IBOutlet weak var txt_time: UITextField!
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        myprogress.progress = 0.05
        
        // Do any additional setup after loading the view.
            
        }
        
        @IBAction func btn_calculate(_ sender: Any) {
            if let ammount = Double(txt_ammount.text!)
            {
                principal = ammount
                
            }
            
            else
            {
                
                print("Error..!!")
            }
            
            rate = Double(myprogress.progress*100)
            if let time = Double(txt_time.text!)
            {
                term=time
                
            }
            else
            {
                print("Error..!!")
            }
            
            let payment = loanPayment(principal: principal, rate: rate, term: term)
            
            lbl_value.text="\(payment)"
          
        }
        
    func loanPayment(principal: Double, rate: Double, term: Double) -> Double {
            let r = rate / 100 / 12
            let n = term * 12
            return (principal * r) / (1 - pow((1+r), -n))
        
        
    }
    
}
