//
//  TaxViewController.swift
//  Financial Calculator
//
//  Created by Khs on 12/01/23.
//

import UIKit

class TaxViewController: UIViewController {

    @IBOutlet weak var txt_ammount: UITextField!
    
    @IBOutlet weak var lbl_value: UILabel!
    
    override func viewDidLoad() {
        super.viewDidLoad()

        // Do any additional setup after loading the view.
    }
    

    @IBAction func btn_calculate(_ sender: Any) {
        let txt_ammount = Double(txt_ammount.text!)!
                var tax_slab = 0.0

                if txt_ammount < 500000 {
                    tax_slab = 0
                } else if txt_ammount <= 700000 {
                    tax_slab = 5
                } else if txt_ammount <= 1000000 {
                    tax_slab = 10
                } else if txt_ammount <= 1300000 {
                    tax_slab = 15
                } else if txt_ammount <= 1500000 {
                    tax_slab = 20
                } else if txt_ammount > 1500000 {
                    tax_slab = 30
                }

                let tax = txt_ammount * tax_slab
                lbl_value.text = "Tax slab: \(tax_slab * 100)%, Tax: \(tax)"
            }
        
    }
    
