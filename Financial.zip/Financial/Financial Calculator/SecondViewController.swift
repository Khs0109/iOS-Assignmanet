//
//  SecondViewController.swift
//  Financial Calculator
//
//  Created by Khs on 09/01/23.
//

import UIKit

class SecondViewController: UIViewController, UITableViewDataSource,UITableViewDelegate {
    
    
    var Lblcell = [""]

    @IBOutlet weak var mytable: UITableView!
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        mytable.rowHeight = UITableView.automaticDimension
        mytable.estimatedRowHeight = 600

        // Do any additional setup after loading the view.
        
        Lblcell = ["A Financial Calculator is a device designed to perform certain equation that a basic calculator can not handle","It is created with stand-alone keys, not available on other types of calculators, which allows it to perform more direct calculations "," A calculator is a device that performs arithmetic operations on numbers. Basic calculators can do only addition, subtraction, multiplication and division mathematical calculations"," This technology allows students solve complicated problems quickly and in an efficient manner."," It has standalone keys for many financial calculations and functions, making such calculations more direct than on standard calculators"]
        
        
    }
    
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return Lblcell.count
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        var cell=MyTableViewCell()
        cell=tableView.dequeueReusableCell(withIdentifier: "cell2") as! MyTableViewCell
        cell.lbl_cell.text=Lblcell[indexPath.row]
        return cell
    }
    
}
