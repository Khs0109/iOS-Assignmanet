//
//  ViewController.swift
//  Financial Calculator
//
//  Created by Khs on 09/01/23.
//

import UIKit

class ViewController: UIViewController {

    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view.
    }

    @IBAction func btn_compound(_ sender: Any) {
        
        let CompoundVC = storyboard?.instantiateViewController(withIdentifier: "CompoundVC") as! CompoundViewController
        navigationController?.pushViewController(CompoundVC, animated: true)
    }
    @IBAction func btn_tax(_ sender: Any) {
        
        let TaxVC = storyboard?.instantiateViewController(withIdentifier: "TaxVC")   as! TaxViewController
        navigationController?.pushViewController(TaxVC, animated: true)
    }
    
    @IBAction func btn_loan(_ sender: Any) {
        
        let LoanVC = storyboard?.instantiateViewController(withIdentifier: "LoanVC") as! LoanViewController
        navigationController?.pushViewController(LoanVC, animated: true)
        
    }
    
    
    @IBAction func btn_stocks(_ sender: Any) {
        
        let StockVC = storyboard?.instantiateViewController(withIdentifier: "StockVC") as! StockViewController
        navigationController?.pushViewController(StockVC, animated: true)
    }
}

