//
//  CompoundViewController.swift
//  Financial Calculator
//
//  Created by Khs on 09/01/23.
//

import UIKit

class CompoundViewController: UIViewController {
    
    @IBOutlet weak var txt_ammount: UITextField!
    
    @IBOutlet weak var lbl_value: UILabel!
    
    @IBOutlet weak var txt: UITextField!
    
    @IBOutlet weak var txt_time: UITextField!

    override func viewDidLoad() {
        super.viewDidLoad()

        // Do any additional setup after loading the view.
        
    }
    
    @IBAction func btn_calculate(_ sender: Any) {
        
        let principal = Double(txt_ammount.text!) ?? 0.0
        let rate = Double(txt.text!) ?? 0.0
        let time = Double(txt_time.text!) ?? 0.0
        
        func compoundIntrest(principal: Double, rate: Double, time: Double) -> Double
        {
            return principal*pow((1+rate/100),time)
            
        }
        lbl_value.text = String(compoundIntrest(principal: principal, rate: rate, time: time))
        
    }
    

}
