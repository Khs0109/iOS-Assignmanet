//
//  ViewController.swift
//  APP - 1
//
//  Created by Khs on 21/12/22.
//

import UIKit

class ViewController: UIViewController {
    
    var Sub = [""]

    @IBOutlet weak var sub_table: UITableView!
    
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view.
        Sub = ["iOS","Android","PHP","React JS","JAVA","C++","C#","SEO","Networking","Python","React Native","OS","Oracle","Wordpress","IOT"]
        
        
    }


}

extension ViewController:UITableViewDataSource, UITableViewDelegate{
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return Sub.count
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        
        let cell = sub_table.dequeueReusableCell(withIdentifier: "cell", for: indexPath)
        cell.textLabel?.text = Sub[indexPath.row]
        return cell
    }
    
    
}

