//
//  MyTableViewCell.swift
//  APP 4-5
//
//  Created by Khs on 24/12/22.
//

import UIKit

class MyTableViewCell: UITableViewCell {
    
    @IBOutlet weak var my_img: UIImageView!
    @IBOutlet weak var my_lbl: UILabel!

}
