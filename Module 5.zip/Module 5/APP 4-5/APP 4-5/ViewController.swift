//
//  ViewController.swift
//  APP 4-5
//
//  Created by Khs on 24/12/22.
//

import UIKit

class ViewController: UIViewController,UITableViewDataSource,UITableViewDelegate
{
    struct Places {
        
        let title: String
        let imageName: String
        
    }
    
    let data: [Places] = [
        
       Places(title: "Beautifull Evening in Dubai", imageName: "Canada"),
       Places(title: "Beautifull Evening in Dubai", imageName: "Dubai"),
       Places(title: "Beautifull Evening in Dubai", imageName: "Santorini"),
       Places(title: "Beautifull Evening in Dubai", imageName: "Phuket"),
       Places(title: "Beautifull Evening in Dubai", imageName: "Paris"),
       Places(title: "Beautifull Evening in Dubai", imageName: "Maldives"),
    ]

    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view.
        
    }
    
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return data.count
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let Places = data[indexPath.row]
        let cell = tableView.dequeueReusableCell(withIdentifier: "cell", for: indexPath) as! MyTableViewCell
        cell.my_lbl.text = Places.title
        cell.my_img.image = UIImage(named: Places.imageName)
        return cell
    }
    

}

    
    
    
    
    
    
    
    
    


    
    
    
    
    
    
    
    
    
    

