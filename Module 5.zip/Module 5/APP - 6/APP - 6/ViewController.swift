//
//  ViewController.swift
//  APP - 6
//
//  Created by Khs on 24/12/22.
//

import UIKit

class ViewController: UIViewController, UITableViewDataSource,UITableViewDelegate {
    
    var Lblcell = [""]
    
    @IBOutlet weak var my_tableview: UITableView!
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        my_tableview.rowHeight = UITableView.automaticDimension
        my_tableview.estimatedRowHeight = 600
        
        // Do any additional setup after loading the view.
        
        Lblcell = ["Unveiled in 2007 for the first-generation iPhone, iOS has since been extended to support other Apple devices such as the iPod Touch (September 2007) and the iPad (introduced: January 2010; availability: April 2010.) As of March 2018, Apple's App Store contains more than 2.1 million iOS applications, 1 million of which are native for iPads.","Major versions of iOS are released annually. The current stable version, iOS 15, was released to the public on September 20, 2021.","It is the basis for three other operating systems made by Apple: iPadOS, tvOS, and watchOS. It is proprietary software, although some parts of it are open source under the Apple Public Source License and other licenses.","In 2005, when Steve Jobs began planning the iPhone, he had a choice to either - shrink the Mac, which would be an epic feat of engineering, or enlarge the iPod. Jobs favored the former approach but pitted the Macintosh and iPod teams, led by Scott Forstall and Tony Fadell, respectively, against each other in an internal competition, with Forstall winning by creating the iPhone OS. The decision enabled the success of the iPhone as a platform for third-party developers: using a well-known desktop operating system as its basis allowed the many third-party Mac developers to write software for the iPhone with minimal retraining. Forstall was also responsible for creating a software development kit for programmers to build iPhone apps, as well as an App Store within iTunes.","The decision enabled the success of the iPhone as a platform for third-party developers: using a well-known desktop operating system as its basis allowed the many third-party Mac developers to write software for the iPhone with minimal retraining.","Forstall was also responsible for creating a software development kit for programmers to build iPhone apps, as well as an App Store within iTunes.","The operating system was unveiled with the iPhone at the Macworld Conference & Expo on January 9, 2007, and released in June of that year.","In September 2007, Apple announced the iPod Touch, a redesigned iPod based on the iPhone form factor.","On January 27, 2010, Apple introduced their much-anticipated media tablet, the iPad, featuring a larger screen than the iPhone and iPod Touch, and designed for web browsing, media consumption, and reading, and offering multi-touch interaction with multimedia formats including newspapers, e-books, photos, videos, music, word processing documents, video games, and most existing iPhone apps using a 9.7-inch screen.","t also includes a mobile version of Safari for web browsing, as well as access to the App Store, iTunes Library, iBookstore, Contacts, and Notes. Content is downloadable via Wi-Fi and optional 3G service or synced through the user's computer.","In June 2010, Apple rebranded iPhone OS as iOS.","The trademark iOS had been used by Cisco for over a decade for its operating system, IOS, used on its routers. To avoid any potential lawsuit, Apple licensed the iOS trademark from Cisco."]
        
    }
    
    
    public func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return Lblcell.count
    }
    
    public func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        var cell=MyTableViewCell()
        cell=tableView.dequeueReusableCell(withIdentifier: "cell") as! MyTableViewCell
        cell.lbl_cell.text=Lblcell[indexPath.row]
        return cell
        
        
    }
    
    func tableView(_ tableView: UITableView, editingStyleForRowAt indexPath: IndexPath) -> UITableViewCell.EditingStyle {
        return .delete
    }
     
    func tableView(_ tableView: UITableView, commit editingStyle: UITableViewCell.EditingStyle, forRowAt indexPath: IndexPath) {
        if editingStyle == .delete{
            tableView.beginUpdates()
            Lblcell.remove(at: indexPath.row)
            tableView.deleteRows(at: [indexPath], with: .fade)
            tableView.endUpdates()
            
            
        }
  }
    
}


