//
//  ViewController.swift
//  APP - 9
//
//  Created by Khs on 03/01/23.
//

import UIKit

class ViewController: UIViewController {
    
    @IBOutlet weak var txt_psw: UITextField!
    @IBOutlet weak var txt_unm: UITextField!
    
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view.
    }
    
   
    @IBAction func btn_add(_ sender: Any) {
        let SecondVC = storyboard?.instantiateViewController(withIdentifier: "SecondVC") as! SecondViewController
       /* SecondVC.str=txt_unm.text!
        SecondVC.str=txt_psw.text!*/
        
        UserDefaults.standard.setValue(txt_unm.text!, forKey: "txtunm")
        navigationController?.pushViewController(SecondVC, animated: true)
        
        UserDefaults.standard.setValue(txt_psw.text!, forKey: "txtpsw")
        navigationController?.pushViewController(SecondVC, animated: true)
        
        
        
        
        
        
    }
    
}

