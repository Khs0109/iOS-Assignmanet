//
//  SecondViewController.swift
//  APP - 9
//
//  Created by Khs on 03/01/23.
//

import UIKit

class SecondViewController: UIViewController {
    
    var str = ""

    @IBOutlet weak var psw_lbl: UILabel!
    @IBOutlet weak var unm_lbl: UILabel!
    override func viewDidLoad() {
        super.viewDidLoad()

        // Do any additional setup after loading the view.
        
        /*unm_lbl.text=str
        psw_lbl.text=str*/
        
        unm_lbl.text=(UserDefaults.standard.value(forKey: "txtunm") as! String)
        
        psw_lbl.text=(UserDefaults.standard.value(forKey: "txtpsw") as! String)
        
        
        
    }
    

}
