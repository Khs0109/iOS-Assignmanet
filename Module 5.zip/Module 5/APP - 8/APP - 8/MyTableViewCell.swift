//
//  MyTableViewCell.swift
//  APP - 8
//
//  Created by Khs on 02/01/23.
//

import UIKit

class MyTableViewCell: UITableViewCell {

    @IBOutlet weak var myCollection: UICollectionView!
    
    override func awakeFromNib() {
        super.awakeFromNib()
        // Initialization code
    }

    override func setSelected(_ selected: Bool, animated: Bool) {
        super.setSelected(selected, animated: animated)

        // Configure the view for the selected state
    }
    
}
extension MyTableViewCell: UICollectionViewDelegate,UICollectionViewDataSource{
    
    func collectionView(_ collectionView: UICollectionView, numberOfItemsInSection section: Int) -> Int {
        return data[collectionView.tag].Places.count
    }
    
    func collectionView(_ collectionView: UICollectionView, cellForItemAt indexPath: IndexPath) -> UICollectionViewCell {
        let cell = collectionView.dequeueReusableCell(withReuseIdentifier: "cell2", for:  indexPath) as! MyCollectionViewCell
        cell.myimg.image = UIImage(named: data[collectionView.tag].Places[indexPath.row])
        return cell
    }
}
