//
//  MyCollectionViewCell.swift
//  APP - 8
//
//  Created by Khs on 02/01/23.
//

import UIKit

class MyCollectionViewCell: UICollectionViewCell {
    
    @IBOutlet weak var myimg: UIImageView!
}
