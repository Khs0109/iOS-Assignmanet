//
//  ViewController.swift
//  APP - 8
//
//  Created by Khs on 02/01/23.
//

import UIKit

var data = [Placesdetails(SectionType: "Beautifull Night", Places: ["Dubai","Maldives","Canad",]),
            Placesdetails(SectionType: "Beautifull Morning", Places: ["India","Phuket","Maldives"])
          ]
            

class ViewController: UIViewController {

    @IBOutlet weak var mytable: UITableView!
    
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view.
    }


}
extension ViewController: UITableViewDelegate,UITableViewDataSource{
    
    func numberOfSections(in tableView: UITableView) -> Int {
        return data.count
    }
    
    func tableView(_ tableView: UITableView, titleForHeaderInSection section: Int) -> String? {
        return data[section].SectionType
    }
    
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return 1
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cell = tableView.dequeueReusableCell(withIdentifier: "cell", for: indexPath) as! MyTableViewCell
        cell.myCollection.tag = indexPath.section
        return cell
    }
    
    func tableView(_ tableView: UITableView, willDisplayHeaderView view: UIView, forSection section: Int) {
        view.tintColor = .gray
    }
    
    
    
    
    
    
    
    
    
    
    
    
}

