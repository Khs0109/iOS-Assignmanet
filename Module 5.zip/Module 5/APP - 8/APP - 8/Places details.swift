//
//  Places details.swift
//  APP - 8
//
//  Created by Khs on 02/01/23.
//

import Foundation

struct Placesdetails {
    
    let SectionType:String
    let Places:[String]
    
    
    
    
    
    
    
}
