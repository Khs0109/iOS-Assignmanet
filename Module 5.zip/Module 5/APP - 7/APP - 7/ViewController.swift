//
//  ViewController.swift
//  APP - 7
//
//  Created by Khs on 30/12/22.
//

import UIKit

class ViewController: UIViewController {

    @IBOutlet weak var my_table: UITableView!
    
    var Animal = [""]
    
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view.
        
        Animal = ["Cat","Dog","Birds","Fish","Panda","Lion","Tiger","Birds","Zibra","Monkey","Rabbit","Deer","Camel","Humwn"]
    }


}

extension ViewController: UITableViewDataSource,UITableViewDelegate
{
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return Animal.count
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cell = my_table.dequeueReusableCell(withIdentifier: "cell", for: indexPath)
        cell.textLabel?.text = Animal[indexPath.row]
        return cell
    }
    
    func tableView(_ tableView: UITableView, accessoryButtonTappedForRowWith indexPath: IndexPath) {
        let alert=UIAlertController(title:"Error..!", message:Animal[indexPath.row], preferredStyle: .alert)
        let ok=UIAlertAction(title: "Ok", style: .default, handler: nil)
        let more=UIAlertAction(title: "MORE", style: .destructive, handler: nil)
        alert.addAction(ok)
        alert.addAction(more)
        present(alert, animated: true, completion: nil)
    }
    
    /*func tableView(_ tableView: UITableView, editingStyleForRowAt indexPath: IndexPath) -> UITableViewCell.EditingStyle {
        
            if indexPath.section==0
            {
                if (editingStyle == .delete)
                {
                    Animal.remove(at: indexPath.row)
                    tableView.deleteRows(at: [indexPath], with: .automatic)
                }
            }
    }*/
    
    
    func tableView(_ tableView: UITableView, editActionsForRowAt indexPath: IndexPath) -> [UITableViewRowAction]?
    {
        if indexPath.section==0
        {
            let btn1=UITableViewRowAction(style: .default, title: "Add") { (btn_add, indexpath) in
                
                print("Button Add Clciked!")
                let alert=UIAlertController(title: "Add", message: "Please add your items!", preferredStyle: .alert)
                let ok=UIAlertAction(title: "Cancel", style: .default, handler: nil)
                let more=UIAlertAction(title: "Add", style: .destructive, handler: nil)
                alert.addAction(ok)
                alert.addAction(more)
                self.present(alert, animated: true, completion: nil)
            }
            btn1.backgroundColor=UIColor.purple
            let btn2=UITableViewRowAction(style: .normal, title: "Update") { (btn_update, indexpath) in
                
                print("Button Update Clciked!")
            }
            let btn3=UITableViewRowAction(style: .destructive, title: "Delete") { (btn_delete, indexpath) in
                
                print("Button Delete Clciked!")
            }
            return [btn1,btn2,btn3]
        }
        return nil
        
        func tableView(_ tableView: UITableView, editingStyleForRowAt indexPath: IndexPath) -> UITableViewCell.EditingStyle {
            return .delete
        }
        
        func tableView(_ tableView: UITableView, commit editingStyle: UITableViewCell.EditingStyle, forRowAt indexPath: IndexPath) {
            if editingStyle == .delete{
                tableView.beginUpdates()
                Animal.remove(at: indexPath.row)
                tableView.deleteRows(at: [indexPath], with: .fade)
                tableView.endUpdates()
            }
        }
    }
    
}

