//
//  ViewController.swift
//  APP - 2-3
//
//  Created by Khs on 23/12/22.
//

import UIKit

class ViewController: UIViewController {
    
    
    
    @IBOutlet weak var mytable: UITableView!
    
    var Tech =  [
        Techdata(Technologies: "App Development Courses", Subjectlist: ["iOS","Android","Flutter","React Native"]),
        Techdata(Technologies: "Web Development Courses", Subjectlist: ["PHP","Python","JAVA","C#"]),
        Techdata(Technologies: "Fullstack Development Courses", Subjectlist:["React JS","React Native","Node JS"])
]
    
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view.
        
    }


}

extension UIViewController: UITableViewDataSource, UITableViewDelegate{
    
    public func numberOfSections(in tableView: UITableView) -> Int {
        return 3
    }
    
    public func tableView(_ tableView: UITableView, titleForHeaderInSection section: Int) -> String? {
        return Tech[section].Technologies
    }
    
    public func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return Tech[section].Subjectlist.count
    }
    
    public func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cell = mytable.dequeueReusableCell(withIdentifier: "cell", for: indexPath)
        cell.textLabel?.text = Techdata[indexPath.section].Subjectlist[indexPath.row]
        return cell
    }
    public func tableView(_ tableView: UITableView, willDisplayHeaderView view: UIView, forSection section: Int) {
        view.tintColor = .black
    }
    
    public func tableView(_ tableView: UITableView, willDisplay cell: UITableViewCell, forRowAt indexPath: IndexPath) {
        view.tintColor = .gray
    }
    
}
