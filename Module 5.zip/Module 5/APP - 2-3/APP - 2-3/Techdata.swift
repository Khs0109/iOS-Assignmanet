//
//  Techdata.swift
//  APP - 2-3
//
//  Created by Khs on 23/12/22.
//

import Foundation

struct Techdata
{
    
    let Technologies:String
    let Subjectlist: [String]
    
}
