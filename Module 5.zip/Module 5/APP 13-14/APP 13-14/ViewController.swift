//
//  ViewController.swift
//  APP 13-14
//
//  Created by Khs on 06/01/23.
//

import UIKit

class ViewController: UIViewController {

    @IBOutlet weak var reqemail_lbl: UILabel!
    
    @IBOutlet weak var txt_email: UITextField!
    
    @IBOutlet weak var txt_psw: UITextField!
    
    @IBOutlet weak var reqpsw_lbl: UILabel!
    
    @IBOutlet weak var txt_number: UITextField!
    
    @IBOutlet weak var btn_submit: UIButton!
    
    @IBOutlet weak var reqno_lbl: UILabel!
    
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view.
        
    }
    
    func ResetForm()
    
    {
        btn_submit.isEnabled = false
        reqemail_lbl.isHidden = false
        reqpsw_lbl.isHidden = false
        reqno_lbl.isHidden = false
        
        reqemail_lbl.text = "Required"
        reqpsw_lbl.text = "Required"
        reqno_lbl.text = "Required"
        
        txt_email.text = ""
        txt_psw.text = ""
        txt_number.text = ""
        
    }

    @IBAction func Email_changed(_ sender: Any) {
        if let email = txt_email.text
        {
            
                if let errorMessage = invalidEmail(email)
                {
                    reqemail_lbl.text = errorMessage
                    reqemail_lbl.isHidden = false
                }
                else
                {
                    reqemail_lbl.isHidden = true
                }
            
        }
        
        
        CheckforValidForm()
        
    }
    
   func  invalidEmail (_ value: String) -> String?
    
    {
        let regularExpression = "[A-Z0-9a-Z._%+-]+[A-Z0-9a-Z._%+-]+//.[A-Za-a]{2,45)"
        let predicate = NSPredicate(format: "SELF MATCHES", regularExpression)
        
        if !predicate.evaluate(with: value)
        {
            return "Invalid Email Address"
        }
        
        return nil
    
    }
    
    @IBAction func psw_changes(_ sender: Any) {
        
        if let Password = txt_psw.text
        {
            if let errorMessage = invalidPassword(Password)
            {
                reqpsw_lbl.text = errorMessage
                reqpsw_lbl.isHidden = false
            }
            else
            {
                reqpsw_lbl.isHidden = true
            }
        
        }
        
        CheckforValidForm()
        
    }
    
    func  invalidPassword (_ value: String) -> String?
    
    {
        
        if value.count < 8
        {
            return "Your Password Must be at least 8 character"
        
        }
        
        if containsDigits(value)
        {
            return "Your Password Contains at least 1 digit"
            
        }
        
        if containsLowerCase(value)
        {
            return "Your Password Contains at least 1 contains LowerCase "
        }
        
        if containsUpperCase(value)
        {
            return "Your Password Contains at least 1 contains UpperCase "
        }
        
        let regularExpression = "[A-Z0-9a-Z._%+-]+[A-Z0-9a-Z._%+-]+//.[A-Za-a]{2,45)"
        let predicate = NSPredicate(format: "SELF MATCHES%@", regularExpression)
        
        if containsDigits(value)
        {
            return "Your Password Contains at least 1 digit"
        }
        
        return nil
        
    }
    func containsDigits (_ value: String) -> Bool
    {
        
        let regularExpression = ".*[0-9]+.*"
        let predicate = NSPredicate(format: "SELF MATCHES@%", regularExpression)
        
        return !predicate.evaluate(with: value)
        
    }
    
    func containsLowerCase (_ value: String) -> Bool
    {
        
        let regularExpression = ".*[a-z]+.*"
        let predicate = NSPredicate(format: "SELF MATCHES@%", regularExpression)
        
        return !predicate.evaluate(with: value)
        
    }
    
    func containsUpperCase (_ value: String) -> Bool
    {
        
        let regularExpression = ".*[A-Z]+.*"
        let predicate = NSPredicate(format: "SELF MATCHES@%", regularExpression)
        
        return !predicate.evaluate(with: value)
        
    }
    
    
    @IBAction func no_changed(_ sender: Any) {
        
        if let phoneNumber = txt_number.text
        {
            if let errorMessage = invalidPhoneNumber(phoneNumber)
            {
                reqno_lbl.text = errorMessage
                reqno_lbl.isHidden = false
            }
            else
            {
                reqno_lbl.isHidden = true
            }
        
        }
        CheckforValidForm()
    }
    
    func invalidPhoneNumber (_ value: String) -> String?
    
    {
        let set = CharacterSet(charactersIn: value)
        if !CharacterSet.decimalDigits.isSuperset(of: set)
        {
            return "Phone Number Must be Contains only Digits"
            
        }
        
        
        if value.count != 10
        {
            return "Phone Number Must be 10 Digits in Length"
            
        }
        
        return nil
    }
    
    func CheckforValidForm()
    {
        if reqemail_lbl.isHidden && reqpsw_lbl.isHidden && reqno_lbl.isHidden
        {
            
            btn_submit.isEnabled = true
        }
        
        else
        {
            btn_submit.isEnabled = false
            
        }
        
        
    }
    
    
    @IBAction func btn_submit(_ sender: Any) {
        
        ResetForm()
        
    }
}

