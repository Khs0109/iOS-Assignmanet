//
//  ViewController.swift
//  APP - 10
//
//  Created by Khs on 03/01/23.
//

import UIKit

class ViewController: UIViewController {

    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view.
    }

    @IBAction func btn_welcome(_ sender: Any) {
        let SecondVC = storyboard?.instantiateViewController(withIdentifier: "SecondVC") as! SecondViewController
        navigationController?.pushViewController(SecondVC, animated: true)
        
    }
    
}

