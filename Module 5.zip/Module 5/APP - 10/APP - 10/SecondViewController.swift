//
//  SecondViewController.swift
//  APP - 10
//
//  Created by Khs on 04/01/23.
//

import UIKit

class SecondViewController: UIViewController {

    @IBOutlet weak var txt_city: UITextField!
    @IBOutlet weak var txt_sub: UITextField!
    @IBOutlet weak var txt_name: UITextField!
    override func viewDidLoad() {
        super.viewDidLoad()

        // Do any additional setup after loading the view.
    }
    
    @IBAction func btn_submit(_ sender: Any) {
        
        let HomeVC = storyboard?.instantiateViewController(withIdentifier: "HomeVC") as! HomeViewController
        
        
        UserDefaults.standard.set(txt_name.text!, forKey: "txtname")
        navigationController?.pushViewController(HomeVC, animated: true)
        
        UserDefaults.standard.set(txt_sub.text!, forKey: "txtsub")
        navigationController?.pushViewController(HomeVC, animated: true)
        
        UserDefaults.standard.set(txt_name.text!, forKey: "txtcity")
        navigationController?.pushViewController(HomeVC, animated: true)
        
        
    }

}
