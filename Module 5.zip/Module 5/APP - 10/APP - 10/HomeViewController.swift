//
//  HomeViewController.swift
//  APP - 10
//
//  Created by Khs on 04/01/23.
//

import UIKit

class HomeViewController: UIViewController {

    @IBOutlet weak var lbl_city: UILabel!
    @IBOutlet weak var lbl_subject: UILabel!
    @IBOutlet weak var lbl_name: UILabel!
    override func viewDidLoad() {
        super.viewDidLoad()

        // Do any additional setup after loading the view.
        
        lbl_name.text=(UserDefaults.standard.value(forKey: "txtname") as! String)
        
        lbl_subject.text=(UserDefaults.standard.value(forKey: "txtsub") as! String)
        
        lbl_city.text=(UserDefaults.standard.value(forKey: "txtcity") as! String)
        
    }
    

}
