//
//  ViewController.swift
//  APP - 12
//
//  Created by Khs on 05/01/23.
//

import UIKit

class ViewController: UIViewController {

    @IBOutlet weak var my_table: UITableView!
     
    var States = [String]()
    var City = [String]()
    
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view.
        
        let path = Bundle.main.path(forResource: "MyPlist", ofType: "plist")
        let dict = NSDictionary(contentsOfFile: path!)
        
        States = dict?.object(forKey: "States") as! [String]
        City = dict?.object(forKey: "City") as! [String]
        
        
    }
    
    /*override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        let destination = segue.destination as? SecondViewController
        destination?.data = City[my_table.indexPathForSelectedRow!.row]
    }*/


}

extension ViewController: UITableViewDelegate,UITableViewDataSource
{
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return States.count
    }
    
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cell = tableView.dequeueReusableCell(withIdentifier: "cell", for: indexPath)
        cell.textLabel?.text=States[indexPath.row]
        return cell
    }
    
    
    func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {
        let destination = storyboard?.instantiateViewController(withIdentifier: "SecondVC") as! SecondViewController
        destination.data = City[my_table.indexPathForSelectedRow!.row]
        navigationController?.pushViewController(destination, animated: true)
        
        /*self.performSegue(withIdentifier: "segue", sender: self)*/
        
    }
    
    
    
    
    
    
    
    
    
    
    
    
}

