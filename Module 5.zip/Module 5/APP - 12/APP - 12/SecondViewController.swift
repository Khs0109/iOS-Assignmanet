//
//  SecondViewController.swift
//  APP - 12
//
//  Created by Khs on 05/01/23.
//

import UIKit

class SecondViewController: UIViewController {

    @IBOutlet weak var lbl_city: UILabel!
    
    var data = ""
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        lbl_city.text = data

        // Do any additional setup after loading the view.
    }
    

    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destination.
        // Pass the selected object to the new view controller.
    }
    */

}
