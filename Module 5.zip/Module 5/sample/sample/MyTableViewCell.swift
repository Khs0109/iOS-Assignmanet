//
//  MyTableViewCell.swift
//  sample
//
//  Created by Khs on 28/12/22.
//

import UIKit

class MyTableViewCell: UITableViewCell {

    @IBOutlet weak var myimg : UIImageView!
    @IBOutlet weak var mylbl : UILabel!
    
    
    override func awakeFromNib() {
        super.awakeFromNib()
        // Initialization code
    }

    override func setSelected(_ selected: Bool, animated: Bool) {
        super.setSelected(selected, animated: animated)

        // Configure the view for the selected state
    }

}
