//
//  ViewController.swift
//  sample
//
//  Created by Khs on 28/12/22.
//

import UIKit

class ViewController: UIViewController
{
    @IBOutlet weak var my_table: UITableView!
    
    var places = [UIImage]()
    var placesname = [""]
    
    override func viewDidLoad() {
        
        super.viewDidLoad()
        // Do any additional setup after loading the view.
        
        placesname = ["Dubai","Maldives","Santorini","Paris","Canada","India","Phuket"]
        places = [#imageLiteral(resourceName: "Paris")]
    }

}
extension ViewController:UITableViewDataSource, UITableViewDelegate{
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return places.count
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cell = tableView.dequeueReusableCell(withIdentifier: "cell", for: indexPath) as! MyTableViewCell
        cell.myimg.image = places[indexPath.row]
        cell.mylbl.text = placesname[indexPath.row]
        return cell
        
    }
    
    
    
    
    
}


